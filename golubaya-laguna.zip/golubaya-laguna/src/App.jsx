import { Component } from "react";
import { api, ApiError } from "./api.js";
import { formatPrice } from "./format.js";
import AgeGate from "./components/AgeGate.jsx";
import Alert from "./components/Alert.jsx";
import BlockedScreen from "./components/BlockedScreen.jsx";
import BookingForm from "./components/BookingForm.jsx";
import CheckIn from "./components/CheckIn.jsx";
import EventCard from "./components/EventCard.jsx";
import Footer from "./components/Footer.jsx";
import Header from "./components/Header.jsx";
import Legend from "./components/Legend.jsx";
import TicketCard from "./components/TicketCard.jsx";
import WheelMap from "./components/WheelMap.jsx";

// Возрастной порог. Совпадает с event.ageLimit в server/event.js.
const AGE_LIMIT = 18;

// Отказ запоминаем в sessionStorage: перезагрузка страницы не должна обходить блокировку.
const AGE_DECLINED_KEY = "golubaya-laguna:age-declined";
// Код последнего тикета — чтобы гость не потерял бронь, обновив страницу.
const LAST_TICKET_KEY = "golubaya-laguna:last-ticket-code";

function readRoute() {
  return window.location.hash.startsWith("#/check") ? "check" : "booking";
}

function readAgeStatus() {
  try {
    return sessionStorage.getItem(AGE_DECLINED_KEY) === "1" ? "blocked" : "pending";
  } catch {
    return "pending";
  }
}

function readSavedCode() {
  try {
    return localStorage.getItem(LAST_TICKET_KEY);
  } catch {
    return null;
  }
}

// Всё состояние приложения живёт здесь: данные вниз уходят через props,
// наверх дочерние компоненты отвечают колбэками.
class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      ageStatus: readAgeStatus(),
      route: readRoute(),
      event: null,
      seats: [],
      freeSeats: 0,
      loading: false,
      loadError: null,
      selectedSeatId: null,
      seatConflict: false,
      submitting: false,
      cancelling: false,
      formErrors: null,
      ticket: null,
      savedCode: readSavedCode(),
      notice: null,
    };

    this.handleHashChange = this.handleHashChange.bind(this);
    this.handleAgeAccept = this.handleAgeAccept.bind(this);
    this.handleAgeDecline = this.handleAgeDecline.bind(this);
    this.handleSelectSeat = this.handleSelectSeat.bind(this);
    this.handleCancelSelection = this.handleCancelSelection.bind(this);
    this.handleSubmitBooking = this.handleSubmitBooking.bind(this);
    this.handleBackToSeats = this.handleBackToSeats.bind(this);
    this.handleShowSavedTicket = this.handleShowSavedTicket.bind(this);
    this.handleCancelBooking = this.handleCancelBooking.bind(this);
    this.handleDismissNotice = this.handleDismissNotice.bind(this);
    this.loadEventData = this.loadEventData.bind(this);
    this.refreshSeats = this.refreshSeats.bind(this);
  }

  componentDidMount() {
    window.addEventListener("hashchange", this.handleHashChange);

    if (this.state.ageStatus === "accepted") {
      this.loadEventData();
    }
  }

  componentWillUnmount() {
    window.removeEventListener("hashchange", this.handleHashChange);
  }

  handleHashChange() {
    this.setState({ route: readRoute() });
  }

  handleAgeAccept() {
    this.setState({ ageStatus: "accepted" });
    this.loadEventData();
  }

  handleAgeDecline() {
    try {
      sessionStorage.setItem(AGE_DECLINED_KEY, "1");
    } catch {
      // приватный режим браузера — блокировка всё равно покажется в этом сеансе
    }

    this.setState({ ageStatus: "blocked", event: null, seats: [], ticket: null });
  }

  async loadEventData() {
    this.setState({ loading: true, loadError: null });

    try {
      const { event, seats, freeSeats } = await api.getEvent();
      this.setState({ event, seats, freeSeats, loading: false });
    } catch (error) {
      this.setState({ loading: false, loadError: error.message });
    }
  }

  async refreshSeats() {
    try {
      const { seats, freeSeats } = await api.getSeats();
      this.setState({ seats, freeSeats });
    } catch {
      // карта обновится при следующей загрузке страницы
    }
  }

  handleSelectSeat(seatId) {
    const seat = this.state.seats.find((item) => item.id === seatId);

    if (!seat || seat.status !== "free") {
      return;
    }

    this.setState((state) => ({
      selectedSeatId: state.selectedSeatId === seatId ? null : seatId,
      seatConflict: false,
      formErrors: null,
      notice: null,
    }));
  }

  handleCancelSelection() {
    this.setState({ selectedSeatId: null, seatConflict: false, formErrors: null });
  }

  async handleSubmitBooking(values) {
    const { selectedSeatId } = this.state;

    this.setState({ submitting: true, formErrors: null, seatConflict: false, notice: null });

    try {
      const { ticket } = await api.createBooking({ ...values, seatId: selectedSeatId });

      try {
        localStorage.setItem(LAST_TICKET_KEY, ticket.code);
      } catch {
        // без локального хранения тикет всё равно остаётся на сервере
      }

      this.setState({ submitting: false, ticket, savedCode: ticket.code });
      await this.refreshSeats();
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        this.setState({ submitting: false, seatConflict: true, formErrors: null });
        await this.refreshSeats();
        return;
      }

      if (error instanceof ApiError && error.status === 422) {
        this.setState({ submitting: false, formErrors: error.fields ?? {} });
        return;
      }

      this.setState({
        submitting: false,
        formErrors: null,
        notice: { tone: "error", title: "Бронь не сохранена", text: error.message },
      });
    }
  }

  handleBackToSeats() {
    this.setState({ ticket: null, selectedSeatId: null, seatConflict: false, formErrors: null });
  }

  async handleShowSavedTicket() {
    const { savedCode } = this.state;

    if (!savedCode) {
      return;
    }

    try {
      const { ticket } = await api.getTicket(savedCode);
      this.setState({ ticket, notice: null });
    } catch {
      try {
        localStorage.removeItem(LAST_TICKET_KEY);
      } catch {
        // не критично
      }

      this.setState({
        savedCode: null,
        notice: {
          tone: "info",
          title: "Сохранённый тикет не найден",
          text: "Возможно, бронь удалили. Оформите место заново.",
        },
      });
    }
  }

  // «Удалить тикет с устройства» теперь отменяет бронь на сервере:
  // место возвращается в свободные и его может занять другой гость.
  async handleCancelBooking() {
    const { ticket, savedCode } = this.state;
    const code = ticket?.code ?? savedCode;

    if (!code) {
      return;
    }

    const seatLabel = ticket?.seat?.label ?? null;

    this.setState({ cancelling: true, notice: null });

    try {
      const response = await api.cancelTicket(code);

      try {
        localStorage.removeItem(LAST_TICKET_KEY);
      } catch {
        // не критично
      }

      this.setState((state) => ({
        cancelling: false,
        ticket: null,
        savedCode: null,
        selectedSeatId: null,
        seats: response.seats ?? state.seats,
        freeSeats: response.freeSeats ?? state.freeSeats,
        notice: {
          tone: "success",
          title: "Бронь отменена",
          text: seatLabel
            ? `${seatLabel} снова свободно — его может занять другой гость.`
            : "Место снова свободно.",
        },
      }));
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        try {
          localStorage.removeItem(LAST_TICKET_KEY);
        } catch {
          // не критично
        }

        this.setState({ cancelling: false, ticket: null, savedCode: null });
        await this.refreshSeats();
        return;
      }

      this.setState({
        cancelling: false,
        notice: { tone: "error", title: "Не удалось отменить бронь", text: error.message },
      });
    }
  }

  handleDismissNotice() {
    this.setState({ notice: null });
  }

  renderBooking() {
    const {
      event,
      seats,
      freeSeats,
      loading,
      loadError,
      selectedSeatId,
      seatConflict,
      submitting,
      formErrors,
      ticket,
      notice,
    } = this.state;

    if (loadError) {
      return (
        <div className="rounded-3xl bg-white/95 p-6 text-slate-900 shadow-xl sm:p-8">
          <Alert tone="error" title="Не удалось загрузить схему мест">
            {loadError}
          </Alert>
          <button
            type="button"
            onClick={this.loadEventData}
            className="mt-4 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-700 focus:outline-none focus-visible:ring-4 focus-visible:ring-sky-300"
          >
            Повторить
          </button>
        </div>
      );
    }

    if (loading || !event) {
      return (
        <div className="flex items-center justify-center gap-3 rounded-3xl border border-white/10 bg-white/5 px-6 py-20 text-cyan-100">
          <span className="h-5 w-5 animate-spin rounded-full border-2 border-cyan-200 border-t-transparent" />
          Загружаем штурвал…
        </div>
      );
    }

    const selectedSeat = seats.find((seat) => seat.id === selectedSeatId) ?? null;

    return (
      <>
        {notice ? (
          <div className="mb-5">
            <Alert tone={notice.tone} title={notice.title} onDismiss={this.handleDismissNotice}>
              {notice.text}
            </Alert>
          </div>
        ) : null}

        {ticket ? (
          <TicketCard
            ticket={ticket}
            cancelling={this.state.cancelling}
            onBack={this.handleBackToSeats}
            onCancel={this.handleCancelBooking}
          />
        ) : (
          <>
            <EventCard event={event} freeSeats={freeSeats} totalSeats={seats.length} />

            {freeSeats === 0 ? (
              <div className="mt-6">
                <Alert tone="warning" title="Все места разобраны">
                  Пять мест у штурвала заняты. Загляните позже: если бронь отменят, место снова
                  станет свободным.
                </Alert>
              </div>
            ) : null}

            <div className="mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
              <section className="rounded-3xl bg-white/95 p-5 text-slate-900 shadow-xl sm:p-8">
                <h2 className="text-lg font-semibold">Шаг 1. Выберите место у штурвала</h2>
                <p className="mt-1 text-sm text-slate-600">
                  Пять мест стоят по кругу — по одной фигуре с эмблемы. Выберите место своего цвета.
                </p>

                <div className="mt-8">
                  <WheelMap
                    seats={seats}
                    selectedSeatId={selectedSeatId}
                    onSelect={this.handleSelectSeat}
                  />
                </div>

                <Legend />
              </section>

              <div className="lg:sticky lg:top-6">
                {selectedSeat ? (
                  <BookingForm
                    seat={selectedSeat}
                    price={event.price}
                    currency={event.currency}
                    submitting={submitting}
                    conflict={seatConflict}
                    serverErrors={formErrors}
                    onSubmit={this.handleSubmitBooking}
                    onCancel={this.handleCancelSelection}
                  />
                ) : (
                  <div className="rounded-3xl border border-dashed border-white/25 bg-white/5 p-6 text-slate-200">
                    <h2 className="text-lg font-semibold text-white">Как забронировать</h2>
                    <ol className="mt-3 space-y-2 text-sm leading-relaxed">
                      <li>1. Нажмите на свободное место вокруг штурвала.</li>
                      <li>2. Укажите имя, телефон и email.</li>
                      <li>
                        3. Получите личный тикет с кодом, оплатите{" "}
                        {formatPrice(event.price, event.currency)} на месте встречи и покажите код
                        организатору.
                      </li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </>
    );
  }

  render() {
    const { ageStatus, route, event, ticket, savedCode } = this.state;

    // До подтверждения возраста ничего, кроме шлюза, не показываем.
    if (ageStatus === "blocked") {
      return <BlockedScreen ageLimit={AGE_LIMIT} />;
    }

    if (ageStatus === "pending") {
      return (
        <AgeGate
          ageLimit={AGE_LIMIT}
          onAccept={this.handleAgeAccept}
          onDecline={this.handleAgeDecline}
        />
      );
    }

    return (
      <div className="lagoon-bg min-h-screen text-slate-100">
        <div className="relative flex min-h-screen flex-col">
          <Header
            route={route}
            savedCode={savedCode}
            showSavedTicket={Boolean(savedCode) && !ticket}
            onShowTicket={this.handleShowSavedTicket}
          />

          <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-12">
            {route === "check" ? <CheckIn /> : this.renderBooking()}
          </main>

          <Footer ageLimit={event?.ageLimit ?? AGE_LIMIT} />
        </div>
      </div>
    );
  }
}

export default App;
