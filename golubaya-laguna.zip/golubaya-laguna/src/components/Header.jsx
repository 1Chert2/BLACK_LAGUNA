import { Component } from "react";
import PropTypes from "prop-types";
import ShipWheel from "./ShipWheel.jsx";

const LINK_BASE =
  "rounded-full px-4 py-2 text-sm font-medium transition focus:outline-none focus-visible:ring-4 focus-visible:ring-cyan-300/50";

// Шапка: логотип, ссылка на страницу контроля и кнопка «Мой тикет»,
// если на этом устройстве уже оформляли бронь.
class Header extends Component {
  render() {
    const { route, savedCode, showSavedTicket, onShowTicket } = this.props;

    return (
      <header className="no-print mx-auto flex w-full max-w-6xl flex-wrap items-center gap-x-4 gap-y-3 px-4 py-6">
        <a href="#/" className="flex items-center gap-3 rounded-2xl focus:outline-none focus-visible:ring-4 focus-visible:ring-cyan-300/50">
          <ShipWheel className="h-11 w-11 shrink-0 drop-shadow" />
          <span>
            <span className="block text-lg font-semibold tracking-wide text-white">Голубая Лагуна</span>
            <span className="block text-[11px] uppercase tracking-[0.25em] text-cyan-300/80">
              Голландский штурвал
            </span>
          </span>
        </a>

        <nav className="ml-auto flex flex-wrap items-center gap-2">
          {showSavedTicket && savedCode ? (
            <button
              type="button"
              onClick={onShowTicket}
              className={`${LINK_BASE} border border-cyan-300/40 bg-cyan-400/10 text-cyan-100 hover:bg-cyan-400/20`}
            >
              Мой тикет {savedCode}
            </button>
          ) : null}

          {route === "check" ? (
            <a href="#/" className={`${LINK_BASE} border border-white/15 bg-white/5 text-slate-200 hover:bg-white/10`}>
              К бронированию
            </a>
          ) : (
            <a href="#/check" className={`${LINK_BASE} border border-white/15 bg-white/5 text-slate-200 hover:bg-white/10`}>
              Контроль тикетов
            </a>
          )}
        </nav>
      </header>
    );
  }
}

Header.propTypes = {
  route: PropTypes.oneOf(["booking", "check"]).isRequired,
  savedCode: PropTypes.string,
  showSavedTicket: PropTypes.bool,
  onShowTicket: PropTypes.func,
};

Header.defaultProps = {
  savedCode: null,
  showSavedTicket: false,
  onShowTicket: () => {},
};

export default Header;
