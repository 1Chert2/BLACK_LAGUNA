import { Component } from "react";
import PropTypes from "prop-types";

// Экран после ответа «Нет» на вопрос о возрасте. Кнопки возврата нет намеренно:
// это и есть блокировка страницы, выйти из неё можно только закрыв вкладку.
class BlockedScreen extends Component {
  render() {
    const { ageLimit, venue } = this.props;

    return (
      <div className="lagoon-bg flex min-h-screen items-center justify-center px-4 py-10">
        <div className="w-full max-w-md space-y-5 text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl border border-rose-500/30 bg-rose-500/10 text-4xl">
            ⛔
          </div>

          <h1 className="text-2xl font-semibold text-white">Доступ закрыт</h1>

          <p className="leading-relaxed text-slate-300">
            {venue} — мероприятие {ageLimit}+. Вы указали, что не достигли этого возраста, поэтому
            забронировать место на «Голландский штурвал» нельзя.
          </p>

          <p className="text-sm text-slate-500">
            Страница останется заблокированной до конца сеанса браузера.
          </p>
        </div>
      </div>
    );
  }
}

BlockedScreen.propTypes = {
  ageLimit: PropTypes.number,
  venue: PropTypes.string,
};

BlockedScreen.defaultProps = {
  ageLimit: 18,
  venue: "«Голубая Лагуна»",
};

export default BlockedScreen;
