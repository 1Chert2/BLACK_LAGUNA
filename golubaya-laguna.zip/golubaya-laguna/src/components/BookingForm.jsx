import { Component } from "react";
import PropTypes from "prop-types";
import Alert from "./Alert.jsx";
import { formatPrice } from "../format.js";

const NAME_PATTERN = /^[\p{L}][\p{L}\s'’-]{1,59}$/u;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const INPUT_BASE =
  "w-full rounded-xl border-2 bg-white px-3.5 py-2.5 text-slate-900 placeholder:text-slate-400 focus:outline-none";

// Шаг 2: контакты гостя. Значения полей — локальное состояние формы,
// а сама бронь создаётся в App через колбэк onSubmit.
class BookingForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      phone: "",
      email: "",
      showErrors: false,
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(changeEvent) {
    const { name, value } = changeEvent.target;

    this.setState({ [name]: value });
  }

  // Правила повторяют серверные: клиент показывает ошибку сразу,
  // но сервер всё равно перепроверяет и может ответить 422 со своими сообщениями.
  validate() {
    const { name, phone, email } = this.state;
    const errors = {};
    const cleanName = name.trim();
    const digitsCount = phone.replace(/\D/g, "").length;

    if (!cleanName) {
      errors.name = "Укажите имя — по нему вас найдут на месте встречи";
    } else if (!NAME_PATTERN.test(cleanName)) {
      errors.name = "От 2 до 60 букв, без цифр и специальных символов";
    }

    if (!phone.trim()) {
      errors.phone = "Укажите телефон для связи";
    } else if (digitsCount < 10 || digitsCount > 15) {
      errors.phone = "Телефон в формате +7 900 000-00-00";
    }

    if (!email.trim()) {
      errors.email = "Укажите email — на него можно продублировать тикет";
    } else if (!EMAIL_PATTERN.test(email.trim())) {
      errors.email = "Проверьте адрес, например name@mail.ru";
    }

    return errors;
  }

  handleSubmit(submitEvent) {
    submitEvent.preventDefault();

    const errors = this.validate();

    if (Object.keys(errors).length > 0) {
      this.setState({ showErrors: true });
      return;
    }

    const { name, phone, email } = this.state;
    const { onSubmit } = this.props;

    onSubmit({ name: name.trim(), phone: phone.trim(), email: email.trim() });
  }

  renderField({ name, label, type, placeholder, autoComplete, error }) {
    return (
      <label className="block" htmlFor={`booking-${name}`}>
        <span className="mb-1.5 block text-sm font-medium text-slate-700">{label}</span>
        <input
          id={`booking-${name}`}
          name={name}
          type={type}
          value={this.state[name]}
          placeholder={placeholder}
          autoComplete={autoComplete}
          onChange={this.handleChange}
          aria-invalid={Boolean(error)}
          className={`${INPUT_BASE} ${
            error ? "border-rose-400 focus:border-rose-500" : "border-slate-200 focus:border-sky-500"
          }`}
        />
        {error ? <span className="mt-1 block text-xs text-rose-600">{error}</span> : null}
      </label>
    );
  }

  render() {
    const { seat, price, currency, submitting, conflict, serverErrors, onCancel } = this.props;
    const { showErrors } = this.state;

    const clientErrors = showErrors ? this.validate() : {};
    const errorFor = (field) => serverErrors?.[field] ?? clientErrors[field] ?? null;
    const isTaken = seat.status !== "free";

    return (
      <form
        onSubmit={this.handleSubmit}
        noValidate
        className="rounded-3xl bg-white/95 p-6 text-slate-900 shadow-xl"
      >
        <h2 className="text-lg font-semibold">Шаг 2. Контактные данные</h2>

        <div className="mt-4 flex items-center justify-between gap-3 rounded-2xl bg-sky-50 px-4 py-3">
          <div>
            <p className="text-sm font-semibold text-sky-900">
              {seat.label} · {formatPrice(price, currency)}
            </p>
            <p className="mt-0.5 text-xs text-sky-700">{seat.hint}</p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg px-2 py-1 text-xs font-medium text-sky-700 underline decoration-dotted transition hover:text-sky-900"
          >
            сменить
          </button>
        </div>

        {conflict || isTaken ? (
          <div className="mt-4">
            <Alert tone="error" title="Это место уже заняли">
              Кто-то успел забронировать {seat.label?.toLowerCase()} раньше. Выберите другое место на
              схеме — данные формы сохранятся.
            </Alert>
          </div>
        ) : null}

        <div className="mt-5 space-y-4">
          {this.renderField({
            name: "name",
            label: "Имя и фамилия",
            type: "text",
            placeholder: "Иван Петров",
            autoComplete: "name",
            error: errorFor("name"),
          })}

          {this.renderField({
            name: "phone",
            label: "Телефон",
            type: "tel",
            placeholder: "+7 900 000-00-00",
            autoComplete: "tel",
            error: errorFor("phone"),
          })}

          {this.renderField({
            name: "email",
            label: "Email",
            type: "email",
            placeholder: "name@mail.ru",
            autoComplete: "email",
            error: errorFor("email"),
          })}
        </div>

        <div className="mt-5 flex items-baseline justify-between border-t border-dashed border-slate-300 pt-4">
          <span className="text-sm text-slate-600">К оплате на месте</span>
          <span className="text-xl font-bold">{formatPrice(price, currency)}</span>
        </div>

        <button
          type="submit"
          disabled={submitting || isTaken}
          className="mt-4 w-full rounded-2xl bg-sky-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-sky-600/25 transition hover:bg-sky-700 focus:outline-none focus-visible:ring-4 focus-visible:ring-sky-300 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:shadow-none"
        >
          {submitting ? "Бронируем…" : `Забронировать ${seat.label?.toLowerCase()}`}
        </button>

        <p className="mt-3 text-xs leading-relaxed text-slate-500">
          Оплата на месте встречи. После бронирования вы получите личный тикет с уникальным кодом —
          по нему организатор выдаст проходку.
        </p>
      </form>
    );
  }
}

BookingForm.propTypes = {
  seat: PropTypes.shape({
    id: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    hint: PropTypes.string,
    status: PropTypes.string.isRequired,
  }).isRequired,
  price: PropTypes.number.isRequired,
  currency: PropTypes.string,
  submitting: PropTypes.bool,
  conflict: PropTypes.bool,
  serverErrors: PropTypes.objectOf(PropTypes.string),
  onSubmit: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
};

BookingForm.defaultProps = {
  currency: "RUB",
  submitting: false,
  conflict: false,
  serverErrors: null,
};

export default BookingForm;
