import { Component } from "react";
import PropTypes from "prop-types";
import { formatDateTime, formatPrice } from "../format.js";

const STATUS_STYLES = {
  awaiting_payment: "border-amber-300 bg-amber-100 text-amber-900",
  used: "border-emerald-300 bg-emerald-100 text-emerald-900",
};

// Личный тикет гостя. Код — единственное, что нужно показать на месте встречи:
// организатор вводит его на странице контроля и выдаёт проходку.
class TicketCard extends Component {
  constructor(props) {
    super(props);

    this.state = { copied: false };
    this.copyTimer = null;

    this.handlePrint = this.handlePrint.bind(this);
    this.handleCopy = this.handleCopy.bind(this);
  }

  componentWillUnmount() {
    if (this.copyTimer) {
      clearTimeout(this.copyTimer);
    }
  }

  handlePrint() {
    window.print();
  }

  async handleCopy() {
    const { ticket } = this.props;

    try {
      await navigator.clipboard.writeText(ticket.code);
      this.setState({ copied: true });
      this.copyTimer = setTimeout(() => this.setState({ copied: false }), 2500);
    } catch {
      // Буфер обмена может быть недоступен (например, страница открыта по http) —
      // код и так виден крупно, копирование не обязательно.
      this.setState({ copied: false });
    }
  }

  render() {
    const { ticket, cancelling, onBack, onCancel } = this.props;
    const { copied } = this.state;
    const isUsed = ticket.status === "used";

    const details = [
      { label: "Дата", value: ticket.event.dateLabel },
      { label: "Время", value: ticket.event.time },
      { label: "Место встречи", value: ticket.event.meetingPoint },
      { label: "Сумма к оплате на месте", value: formatPrice(ticket.price, ticket.currency) },
      { label: "Участник", value: ticket.name },
      { label: "Телефон", value: ticket.phone },
      { label: "Email", value: ticket.email },
      { label: "Бронь оформлена", value: formatDateTime(ticket.createdAt) },
    ];

    return (
      <div className="mx-auto w-full max-w-2xl">
        <div className="print-area relative overflow-hidden rounded-3xl bg-white text-slate-900 shadow-2xl">
          <div className="bg-gradient-to-r from-sky-700 via-cyan-600 to-sky-700 px-6 py-5 text-white sm:px-8">
            <p className="text-xs uppercase tracking-[0.3em] text-cyan-100">{ticket.event.venue}</p>
            <h2 className="mt-1 text-2xl font-semibold">{ticket.event.title}</h2>
            <p className="mt-1 text-sm text-cyan-100">Личный тикет · бронирование места</p>
          </div>

          <div className="px-6 py-6 sm:px-8">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="text-xs uppercase tracking-wider text-slate-500">Ваше место</p>
                <p className="text-4xl font-bold leading-tight">№ {ticket.seat.number}</p>
                <p className="mt-1 text-sm text-slate-500">
                  {ticket.seat.label}
                  {ticket.seat.hint ? ` · ${ticket.seat.hint}` : ""}
                </p>
              </div>

              <span
                className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${
                  STATUS_STYLES[ticket.status] ?? STATUS_STYLES.awaiting_payment
                }`}
              >
                {ticket.statusLabel}
              </span>
            </div>

            <dl className="mt-6 grid gap-x-6 gap-y-4 border-t border-slate-200 pt-5 sm:grid-cols-2">
              {details.map((item) => (
                <div key={item.label}>
                  <dt className="text-[11px] uppercase tracking-wider text-slate-500">{item.label}</dt>
                  <dd className="mt-0.5 text-sm font-medium leading-snug text-slate-900">{item.value}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative border-t-2 border-dashed border-slate-300">
            <span aria-hidden="true" className="no-print absolute -left-4 -top-4 h-8 w-8 rounded-full bg-slate-950" />
            <span aria-hidden="true" className="no-print absolute -right-4 -top-4 h-8 w-8 rounded-full bg-slate-950" />

            <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 px-6 py-5 sm:px-8">
              <div className="min-w-0">
                <p className="text-xs uppercase tracking-wider text-slate-500">Код тикета</p>
                <p className="mt-1 font-mono text-2xl font-bold tracking-[0.15em] text-slate-900 sm:text-3xl">
                  {ticket.code}
                </p>
                <p className="mt-1 text-xs leading-relaxed text-slate-500">
                  Предъявите этот код на месте встречи — по нему выдадут проходку.
                </p>
              </div>

              <button
                type="button"
                onClick={this.handleCopy}
                className="no-print rounded-xl border-2 border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-sky-400 hover:text-sky-700 focus:outline-none focus-visible:ring-4 focus-visible:ring-sky-200"
              >
                {copied ? "Скопировано" : "Скопировать код"}
              </button>
            </div>
          </div>
        </div>

        <div className="no-print mt-5 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={this.handlePrint}
            className="rounded-2xl bg-white px-5 py-2.5 text-sm font-semibold text-slate-900 shadow-lg transition hover:bg-slate-100 focus:outline-none focus-visible:ring-4 focus-visible:ring-white/40"
          >
            Распечатать тикет
          </button>
          <button
            type="button"
            onClick={onBack}
            className="rounded-2xl border border-white/20 bg-white/5 px-5 py-2.5 text-sm font-semibold text-slate-100 transition hover:bg-white/10 focus:outline-none focus-visible:ring-4 focus-visible:ring-cyan-300/40"
          >
            Вернуться к схеме мест
          </button>
          <button
            type="button"
            onClick={onCancel}
            disabled={isUsed || cancelling}
            className="rounded-2xl px-3 py-2.5 text-xs font-medium text-slate-400 underline decoration-dotted transition hover:text-rose-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-300 disabled:cursor-not-allowed disabled:text-slate-500 disabled:no-underline"
          >
            {cancelling
              ? "Отменяем бронь…"
              : isUsed
                ? "Бронь не отменить: проходка выдана"
                : "Отменить бронь и удалить тикет с устройства"}
          </button>
        </div>

        <p className="no-print mt-4 text-center text-xs leading-relaxed text-slate-400">
          Тикет именной и действует на одно место. Код сохранён в этом браузере — после перезагрузки
          страницы нажмите «Мой тикет» в шапке, чтобы вернуть его. Отмена брони освобождает место
          для других гостей; после выдачи проходки отмена недоступна.
        </p>
      </div>
    );
  }
}

TicketCard.propTypes = {
  ticket: PropTypes.shape({
    code: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    phone: PropTypes.string.isRequired,
    email: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    currency: PropTypes.string,
    status: PropTypes.string.isRequired,
    statusLabel: PropTypes.string.isRequired,
    createdAt: PropTypes.string.isRequired,
    seat: PropTypes.shape({
      number: PropTypes.number,
      label: PropTypes.string,
      hint: PropTypes.string,
    }).isRequired,
    event: PropTypes.shape({
      title: PropTypes.string.isRequired,
      venue: PropTypes.string.isRequired,
      dateLabel: PropTypes.string.isRequired,
      time: PropTypes.string.isRequired,
      meetingPoint: PropTypes.string.isRequired,
    }).isRequired,
  }).isRequired,
  onBack: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  cancelling: PropTypes.bool,
};

TicketCard.defaultProps = {
  cancelling: false,
};

export default TicketCard;
