import { Component } from "react";
import PropTypes from "prop-types";

class Footer extends Component {
  render() {
    const { ageLimit } = this.props;

    return (
      <footer className="no-print mx-auto w-full max-w-6xl px-4 pb-10 text-center text-xs leading-relaxed text-slate-400">
        <p>
          {ageLimit}+ · Оплата места на месте встречи · Тикет именной, действует на одно место у
          штурвала
        </p>
        <p className="mt-1 text-slate-500">«Голубая Лагуна» — Голландский штурвал</p>
      </footer>
    );
  }
}

Footer.propTypes = {
  ageLimit: PropTypes.number,
};

Footer.defaultProps = {
  ageLimit: 18,
};

export default Footer;
