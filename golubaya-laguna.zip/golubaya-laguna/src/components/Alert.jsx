import { Component } from "react";
import PropTypes from "prop-types";

const TONES = {
  error: "border-rose-300 bg-rose-50 text-rose-800",
  success: "border-emerald-300 bg-emerald-50 text-emerald-800",
  info: "border-sky-300 bg-sky-50 text-sky-800",
  warning: "border-amber-300 bg-amber-50 text-amber-900",
};

const ICONS = {
  error: "⚠️",
  success: "✅",
  info: "ℹ️",
  warning: "⚡",
};

// Универсальная плашка сообщения: ошибки сервера, успех выдачи проходки, подсказки.
class Alert extends Component {
  render() {
    const { tone, title, children, onDismiss } = this.props;

    return (
      <div
        role={tone === "error" ? "alert" : "status"}
        className={`flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm ${TONES[tone] ?? TONES.info}`}
      >
        <span aria-hidden="true" className="mt-0.5 text-base leading-none">
          {ICONS[tone] ?? ICONS.info}
        </span>

        <div className="min-w-0 flex-1">
          {title ? <p className="font-semibold">{title}</p> : null}
          {children ? <div className={title ? "mt-1 leading-relaxed" : "leading-relaxed"}>{children}</div> : null}
        </div>

        {onDismiss ? (
          <button
            type="button"
            onClick={onDismiss}
            aria-label="Закрыть сообщение"
            className="rounded-lg px-2 py-0.5 text-lg leading-none opacity-60 transition hover:opacity-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-current"
          >
            ×
          </button>
        ) : null}
      </div>
    );
  }
}

Alert.propTypes = {
  tone: PropTypes.oneOf(["error", "success", "info", "warning"]),
  title: PropTypes.string,
  children: PropTypes.node,
  onDismiss: PropTypes.func,
};

Alert.defaultProps = {
  tone: "info",
  title: null,
  children: null,
  onDismiss: null,
};

export default Alert;
