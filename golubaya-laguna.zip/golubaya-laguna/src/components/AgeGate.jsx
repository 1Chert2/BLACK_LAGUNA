import { Component } from "react";
import PropTypes from "prop-types";
import ShipWheel from "./ShipWheel.jsx";

// Возрастной шлюз. Пока гость не подтвердил возраст, контент сайта не рендерится вообще:
// App вместо всех экранов показывает этот компонент.
class AgeGate extends Component {
  render() {
    const { ageLimit, venue, title, onAccept, onDecline } = this.props;

    return (
      <div className="lagoon-bg relative flex min-h-screen items-center justify-center px-4 py-10">
        <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-white/95 p-8 text-slate-900 shadow-2xl">
          <div className="flex items-center gap-4">
            <ShipWheel className="h-14 w-14 shrink-0" />
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-sky-700">{venue}</p>
              <h1 className="text-2xl font-semibold leading-tight">{title}</h1>
            </div>
          </div>

          <p className="mt-6 inline-flex items-center gap-2 rounded-full bg-rose-100 px-3 py-1 text-sm font-semibold text-rose-700">
            <span className="rounded-md bg-rose-600 px-1.5 py-0.5 text-xs text-white">{ageLimit}+</span>
            Мероприятие для взрослых
          </p>

          <p className="mt-4 text-lg font-medium">Вам уже исполнилось {ageLimit} лет?</p>
          <p className="mt-2 text-sm leading-relaxed text-slate-600">
            На борту подаётся крепкий алкоголь, поэтому без подтверждения возраста бронирование места
            недоступно.
          </p>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={onAccept}
              className="rounded-2xl bg-sky-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-sky-600/25 transition hover:bg-sky-700 focus:outline-none focus-visible:ring-4 focus-visible:ring-sky-300"
            >
              Да, мне есть {ageLimit}
            </button>
            <button
              type="button"
              onClick={onDecline}
              className="rounded-2xl border-2 border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-700 focus:outline-none focus-visible:ring-4 focus-visible:ring-rose-200"
            >
              Нет
            </button>
          </div>

          <p className="mt-4 text-xs leading-relaxed text-slate-500">
            Если нажмёте «Нет», страница заблокируется до конца сеанса браузера — перезагрузка не
            поможет.
          </p>
        </div>
      </div>
    );
  }
}

AgeGate.propTypes = {
  ageLimit: PropTypes.number,
  venue: PropTypes.string,
  title: PropTypes.string,
  onAccept: PropTypes.func.isRequired,
  onDecline: PropTypes.func.isRequired,
};

AgeGate.defaultProps = {
  ageLimit: 18,
  venue: "Голубая Лагуна",
  title: "Голландский штурвал",
};

export default AgeGate;
