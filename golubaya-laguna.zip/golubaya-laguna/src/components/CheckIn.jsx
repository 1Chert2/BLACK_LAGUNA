import { Component } from "react";
import { api, ApiError } from "../api.js";
import Alert from "./Alert.jsx";
import { formatDateTime, formatPrice } from "../format.js";

const STATUS_STYLES = {
  awaiting_payment: "border-amber-300 bg-amber-100 text-amber-900",
  used: "border-emerald-300 bg-emerald-100 text-emerald-900",
};

// Страница контроля (#/check) — экран организатора на месте встречи.
// Данные здесь свои и на схему мест не влияют, поэтому состояние живёт в самом
// компоненте, а не в App: страницы «бронирование» и «контроль» независимы.
class CheckIn extends Component {
  constructor(props) {
    super(props);

    this.state = {
      code: "",
      looking: false,
      issuing: false,
      ticket: null,
      error: null,
      justIssued: false,
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleLookup = this.handleLookup.bind(this);
    this.handleIssue = this.handleIssue.bind(this);
    this.handleReset = this.handleReset.bind(this);
  }

  handleChange(event) {
    // Код всегда приводим к верхнему регистру — так его проще сверять с тикетом.
    this.setState({ code: event.target.value.toUpperCase() });
  }

  async handleLookup(event) {
    event.preventDefault();

    const code = this.state.code.trim();

    if (!code) {
      this.setState({ error: "Введите код тикета", ticket: null, justIssued: false });
      return;
    }

    this.setState({ looking: true, error: null, justIssued: false });

    try {
      const { ticket } = await api.checkTicket(code);
      this.setState({ ticket, looking: false });
    } catch (lookupError) {
      this.setState({ ticket: null, looking: false, error: lookupError.message });
    }
  }

  async handleIssue() {
    const { ticket } = this.state;

    if (!ticket) {
      return;
    }

    this.setState({ issuing: true, error: null });

    try {
      const { ticket: issuedTicket } = await api.issuePass(ticket.code);
      this.setState({ ticket: issuedTicket, issuing: false, justIssued: true });
    } catch (issueError) {
      // Тикет могли выдать параллельно — показываем его актуальный статус.
      if (issueError instanceof ApiError && issueError.code === "ALREADY_USED") {
        try {
          const { ticket: freshTicket } = await api.checkTicket(ticket.code);
          this.setState({ ticket: freshTicket });
        } catch {
          // оставляем то, что уже показали
        }
      }

      this.setState({ issuing: false, error: issueError.message });
    }
  }

  handleReset() {
    this.setState({ code: "", ticket: null, error: null, justIssued: false });
  }

  render() {
    const { code, looking, issuing, ticket, error, justIssued } = this.state;
    const isUsed = ticket?.status === "used";

    return (
      <section className="mx-auto w-full max-w-2xl">
        <div className="rounded-3xl bg-white/95 p-6 text-slate-900 shadow-xl sm:p-8">
          <p className="text-xs uppercase tracking-[0.25em] text-sky-700">Для организатора</p>
          <h2 className="mt-1 text-2xl font-semibold">Контроль тикетов</h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-600">
            Введите код с тикета гостя, сверьте имя и место, затем выдайте проходку. Повторно выдать
            проходку по тому же коду не получится.
          </p>

          <form onSubmit={this.handleLookup} className="mt-6 flex flex-wrap gap-3">
            <label className="min-w-[12rem] flex-1" htmlFor="check-code">
              <span className="sr-only">Код тикета</span>
              <input
                id="check-code"
                type="text"
                value={code}
                onChange={this.handleChange}
                placeholder="GL-XXXXXX"
                autoComplete="off"
                spellCheck="false"
                className="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-mono text-lg tracking-[0.15em] text-slate-900 uppercase placeholder:text-slate-400 focus:border-sky-500 focus:outline-none"
              />
            </label>

            <button
              type="submit"
              disabled={looking}
              className="rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition hover:bg-slate-700 focus:outline-none focus-visible:ring-4 focus-visible:ring-sky-300 disabled:bg-slate-400"
            >
              {looking ? "Ищем…" : "Найти тикет"}
            </button>
          </form>

          {error ? (
            <div className="mt-4">
              <Alert tone="error" title="Не получилось">
                {error}
              </Alert>
            </div>
          ) : null}

          {justIssued && ticket ? (
            <div className="mt-4">
              <Alert tone="success" title="Проходка выдана">
                {ticket.name} · {ticket.seat.label}. Гостя можно пускать к штурвалу.
              </Alert>
            </div>
          ) : null}

          {ticket ? (
            <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-wider text-slate-500">Участник</p>
                  <p className="text-xl font-semibold text-slate-900">{ticket.name}</p>
                </div>

                <span
                  className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${
                    STATUS_STYLES[ticket.status] ?? STATUS_STYLES.awaiting_payment
                  }`}
                >
                  {ticket.statusLabel}
                </span>
              </div>

              <dl className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <dt className="text-[11px] uppercase tracking-wider text-slate-500">Место</dt>
                  <dd className="mt-0.5 text-sm font-medium text-slate-900">
                    {ticket.seat.label}
                    {ticket.seat.hint ? ` · ${ticket.seat.hint}` : ""}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase tracking-wider text-slate-500">Сумма</dt>
                  <dd className="mt-0.5 text-sm font-medium text-slate-900">
                    {formatPrice(ticket.price, ticket.currency)}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase tracking-wider text-slate-500">Контакты</dt>
                  <dd className="mt-0.5 text-sm font-medium text-slate-900">
                    {ticket.phone} · {ticket.email}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase tracking-wider text-slate-500">
                    {isUsed ? "Проходка выдана" : "Бронь оформлена"}
                  </dt>
                  <dd className="mt-0.5 text-sm font-medium text-slate-900">
                    {formatDateTime(isUsed ? ticket.usedAt : ticket.createdAt)}
                  </dd>
                </div>
              </dl>

              <div className="mt-5 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={this.handleIssue}
                  disabled={isUsed || issuing}
                  className="rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:bg-emerald-700 focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:shadow-none"
                >
                  {issuing ? "Выдаём…" : isUsed ? "Проходка уже выдана" : "Выдать проходку"}
                </button>

                <button
                  type="button"
                  onClick={this.handleReset}
                  className="rounded-xl border-2 border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:border-slate-400 focus:outline-none focus-visible:ring-4 focus-visible:ring-slate-300"
                >
                  Следующий гость
                </button>
              </div>
            </div>
          ) : null}
        </div>
      </section>
    );
  }
}

export default CheckIn;
