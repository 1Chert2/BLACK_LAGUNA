import { Component } from "react";

// Подсказка под схемой: что значит каждый вид круга.
// «Вы выбрали» показан веером из пяти цветов фигур — у каждого места свой.
const LEGEND = [
  { label: "Свободно", className: "border-2 border-slate-300 bg-white" },
  {
    label: "Вы выбрали",
    className: "border-2 border-white/60",
    style: {
      background:
        "conic-gradient(#e9d26b 0 20%, #29b5c8 0 40%, #7d7250 0 60%, #e0512a 0 80%, #7cb544 0)",
    },
  },
  { label: "Занято", className: "border-2 border-slate-200 bg-slate-200" },
  { label: "Проходка выдана", className: "border-2 border-emerald-300 bg-emerald-100" },
];

class Legend extends Component {
  render() {
    return (
      <div className="mt-6 space-y-2 text-center">
        <ul className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs text-slate-600">
          {LEGEND.map((item) => (
            <li key={item.label} className="flex items-center gap-2">
              <span className={`h-3.5 w-3.5 rounded-full ${item.className}`} style={item.style} />
              {item.label}
            </li>
          ))}
        </ul>
        <p className="text-xs text-slate-500">
          Ободок свободного места повторяет цвет фигуры на эмблеме — по нему легко найти своё место
          в кругу.
        </p>
      </div>
    );
  }
}

export default Legend;
