import { Component } from "react";
import PropTypes from "prop-types";
import { formatPrice } from "../format.js";

// Карточка события: дата, время, место встречи и цена.
// Все значения приходят с сервера из одного конфига (server/event.js).
class EventCard extends Component {
  render() {
    const { event, freeSeats, totalSeats } = this.props;
    const soldOut = freeSeats === 0;

    const items = [
      { label: "Дата", value: event.dateLabel },
      { label: "Время", value: `${event.time}–${event.endTime}` },
      { label: "Место встречи", value: event.meetingPoint, hint: event.address },
      {
        label: "Цена за место",
        value: formatPrice(event.price, event.currency),
        hint: "оплата на месте",
      },
    ];

    return (
      <section className="rounded-3xl border border-white/10 bg-white/10 p-6 backdrop-blur-sm sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-white sm:text-2xl">{event.title}</h2>
            <p className="mt-1 text-sm text-cyan-200/80">{event.venue}</p>
          </div>

          <span
            className={
              soldOut
                ? "rounded-full border border-rose-400/40 bg-rose-500/15 px-4 py-1.5 text-sm font-semibold text-rose-200"
                : "rounded-full border border-emerald-400/40 bg-emerald-500/15 px-4 py-1.5 text-sm font-semibold text-emerald-200"
            }
          >
            {soldOut ? "Мест нет" : `Свободно ${freeSeats} из ${totalSeats}`}
          </span>
        </div>

        <dl className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((item) => (
            <div key={item.label} className="rounded-2xl bg-slate-950/30 px-4 py-3">
              <dt className="text-[11px] uppercase tracking-wider text-cyan-200/70">{item.label}</dt>
              <dd className="mt-1 text-sm font-medium leading-snug text-white">{item.value}</dd>
              {item.hint ? <dd className="mt-0.5 text-xs text-slate-300">{item.hint}</dd> : null}
            </div>
          ))}
        </dl>
      </section>
    );
  }
}

EventCard.propTypes = {
  event: PropTypes.shape({
    title: PropTypes.string.isRequired,
    venue: PropTypes.string.isRequired,
    dateLabel: PropTypes.string.isRequired,
    time: PropTypes.string.isRequired,
    endTime: PropTypes.string,
    meetingPoint: PropTypes.string.isRequired,
    address: PropTypes.string,
    price: PropTypes.number.isRequired,
    currency: PropTypes.string,
  }).isRequired,
  freeSeats: PropTypes.number.isRequired,
  totalSeats: PropTypes.number.isRequired,
};

export default EventCard;
