import { Component } from "react";
import PropTypes from "prop-types";

const STATUS_TEXT = {
  free: "свободно",
  booked: "занято",
  used: "выдано",
};

const BOOKED_STYLES = "cursor-not-allowed border-slate-200 bg-slate-100 text-slate-400";
const USED_STYLES = "cursor-not-allowed border-emerald-200 bg-emerald-50 text-emerald-600";

// На светлых фигурах (жёлтая, зелёная, бирюзовая) подпись читаема тёмным,
// на тёмных (оливковая, оранжевая) — белым. Считаем яркость по тем же весам,
// что использует формула относительной яркости sRGB.
function isLightColor(hex) {
  const value = hex.replace("#", "");
  const red = parseInt(value.slice(0, 2), 16) / 255;
  const green = parseInt(value.slice(2, 4), 16) / 255;
  const blue = parseInt(value.slice(4, 6), 16) / 255;

  return 0.2126 * red + 0.7152 * green + 0.0722 * blue > 0.6;
}

// Кнопка-место. Цвет ободка — цвет фигуры на эмблеме: по нему место находят в кругу.
// Выбранное место заливается своим цветом целиком. Занятое отключено (disabled)
// и не реагирует на клик, чтобы его нельзя было выбрать даже случайно.
class Seat extends Component {
  constructor(props) {
    super(props);

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    const { seat, onSelect } = this.props;

    onSelect(seat.id);
  }

  render() {
    const { seat, isSelected } = this.props;
    const isFree = seat.status === "free";

    let className =
      "flex h-20 w-20 flex-col items-center justify-center rounded-full border-[3px] shadow-md transition focus:outline-none focus-visible:ring-4 focus-visible:ring-sky-300 sm:h-24 sm:w-24";
    let inlineStyle = null;

    if (!isFree) {
      className += ` ${seat.status === "used" ? USED_STYLES : BOOKED_STYLES}`;
    } else if (isSelected) {
      className += ` -translate-y-0.5 ring-4 ring-slate-900/15 ${
        isLightColor(seat.color) ? "text-slate-900" : "text-white"
      }`;
      inlineStyle = { backgroundColor: seat.color, borderColor: seat.color };
    } else {
      className += " bg-white text-slate-800 hover:-translate-y-0.5 hover:shadow-lg";
      inlineStyle = { borderColor: seat.color };
    }

    return (
      <button
        type="button"
        disabled={!isFree}
        onClick={this.handleClick}
        aria-pressed={isSelected}
        aria-label={`${seat.label}, ${seat.hint}, ${isFree ? "свободно" : "занято"}`}
        title={`${seat.label} — ${seat.hint}`}
        style={inlineStyle}
        className={className}
      >
        <span className="text-2xl font-bold leading-none">{seat.number}</span>
        <span className="mt-1 text-[10px] font-semibold uppercase tracking-wide">
          {isSelected ? "ваше место" : STATUS_TEXT[seat.status]}
        </span>
      </button>
    );
  }
}

Seat.propTypes = {
  seat: PropTypes.shape({
    id: PropTypes.string.isRequired,
    number: PropTypes.number.isRequired,
    label: PropTypes.string.isRequired,
    color: PropTypes.string.isRequired,
    hint: PropTypes.string,
    status: PropTypes.oneOf(["free", "booked", "used"]).isRequired,
  }).isRequired,
  isSelected: PropTypes.bool,
  onSelect: PropTypes.func.isRequired,
};

Seat.defaultProps = {
  isSelected: false,
};

export default Seat;
