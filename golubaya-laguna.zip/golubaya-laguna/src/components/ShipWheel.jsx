import { Component } from "react";
import PropTypes from "prop-types";

// Эмблема «Голландского штурвала»: пять переплетённых фигур в кругу.
// Картинка лежит в public/ship-wheel-emblem.png и подготовлена скриптом
// scripts/make-emblem.ps1 из исходника public/ship-wheel.jpg: подпись обрезана,
// белый фон сделан прозрачным, поэтому эмблема одинаково хорошо смотрится
// и на тёмной шапке, и на белых карточках.
class ShipWheel extends Component {
  render() {
    const { className } = this.props;

    return (
      <img
        src="/ship-wheel-emblem.png"
        alt="Эмблема «Голландский штурвал»: пять человек, держащихся за руки в кругу"
        className={className}
        draggable="false"
      />
    );
  }
}

ShipWheel.propTypes = {
  className: PropTypes.string,
};

ShipWheel.defaultProps = {
  className: "h-full w-full object-contain",
};

export default ShipWheel;
