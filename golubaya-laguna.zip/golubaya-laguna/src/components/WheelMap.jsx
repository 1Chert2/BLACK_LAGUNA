import { Component } from "react";
import PropTypes from "prop-types";
import Seat from "./Seat.jsx";
import ShipWheel from "./ShipWheel.jsx";

// Радиус окружности, на которой сидят места, в процентах от стороны квадрата схемы.
// Подобран так, чтобы кнопки не наезжали ни на эмблему в центре, ни на края карточки.
const RADIUS = 38;

// Места расставляем по кругу через угол: первое — сверху, дальше по часовой,
// как фигуры на эмблеме. Раскладка не зависит от количества мест:
// пять сегодня, шесть завтра — править здесь нечего.
function seatStyle(index, total) {
  const angle = (index / total) * 2 * Math.PI - Math.PI / 2;

  return {
    left: `${50 + RADIUS * Math.cos(angle)}%`,
    top: `${50 + RADIUS * Math.sin(angle)}%`,
    transform: "translate(-50%, -50%)",
  };
}

class WheelMap extends Component {
  render() {
    const { seats, selectedSeatId, onSelect } = this.props;

    return (
      <div className="relative mx-auto aspect-square w-full max-w-[26rem] select-none">
        <div className="absolute inset-[26%] flex items-center justify-center">
          <ShipWheel className="wheel-spin h-full w-full object-contain drop-shadow-md" />
        </div>

        {seats.map((seat, index) => (
          <div key={seat.id} className="absolute" style={seatStyle(index, seats.length)}>
            <Seat seat={seat} isSelected={seat.id === selectedSeatId} onSelect={onSelect} />
          </div>
        ))}
      </div>
    );
  }
}

WheelMap.propTypes = {
  seats: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      color: PropTypes.string.isRequired,
      status: PropTypes.string.isRequired,
    })
  ).isRequired,
  selectedSeatId: PropTypes.string,
  onSelect: PropTypes.func.isRequired,
};

WheelMap.defaultProps = {
  selectedSeatId: null,
};

export default WheelMap;
