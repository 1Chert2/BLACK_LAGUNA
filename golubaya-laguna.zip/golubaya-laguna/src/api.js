// Тонкая обёртка над fetch: одна точка, где разбираются ответы сервера и ошибки.
// Если сервер вернул не 2xx, кидаем ApiError с кодом ошибки и сообщениями по полям —
// компоненты сами решают, что с этим делать (409 — место заняли, 422 — не прошли поля).

export class ApiError extends Error {
  constructor(status, code, message, fields = null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.fields = fields;
  }
}

async function request(path, { method = "GET", body } = {}) {
  let response;

  try {
    response = await fetch(path, {
      method,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, "NETWORK", "Сервер бронирования недоступен. Проверьте, запущен ли npm run dev.");
  }

  const text = await response.text();
  let data = null;

  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }

  if (!response.ok) {
    throw new ApiError(
      response.status,
      data?.error?.code ?? "UNKNOWN",
      data?.error?.message ?? `Сервер ответил ошибкой ${response.status}`,
      data?.error?.fields ?? null
    );
  }

  return data;
}

export const api = {
  getEvent: () => request("/api/event"),
  getSeats: () => request("/api/seats"),
  createBooking: (payload) => request("/api/bookings", { method: "POST", body: payload }),
  getTicket: (code) => request(`/api/tickets/${encodeURIComponent(code)}`),
  cancelTicket: (code) =>
    request(`/api/tickets/${encodeURIComponent(code)}`, { method: "DELETE" }),
  checkTicket: (code) => request(`/api/check/${encodeURIComponent(code)}`),
  issuePass: (code) => request(`/api/check/${encodeURIComponent(code)}`, { method: "POST" }),
};
