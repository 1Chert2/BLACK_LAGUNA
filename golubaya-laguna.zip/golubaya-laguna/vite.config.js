import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// В dev-режиме фронтенд живёт на 5173, а запросы к /api проксируются на Express (3001).
// После `npm run build` тот же Express раздаёт папку dist/, поэтому прокси не нужен.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:3001",
    },
  },
});
