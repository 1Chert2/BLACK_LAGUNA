// Единственный конфиг события. Цену, дату, время и место встречи меняют здесь —
// и на сайте, и в тикете, и в ответах API значения появятся автоматически.

export const event = {
  id: "shturval-2026-11-21",
  title: "Голландский штурвал",
  venue: "Голубая Лагуна",
  date: "2026-11-21",
  dateLabel: "Суббота, 21 ноября 2026",
  time: "19:00",
  endTime: "23:00",
  meetingPoint: "Причал «Голубая Лагуна», сбор у трапа за 30 минут до отправления",
  address: "Лазурная набережная, 4",
  price: 1500,
  currency: "RUB",
  ageLimit: 18,

  // Пять мест стоят в кругу — по одному на каждую фигуру эмблемы «Голландского штурвала».
  // color — цвет фигуры на эмблеме: им подсвечено место на схеме, чтобы в кругу его
  // было легко найти глазами («встань на бирюзовое место»).
  seats: [
    {
      id: "seat-1",
      number: 1,
      label: "Место 1",
      color: "#e9d26b",
      hint: "жёлтая фигура — лицом к капитану",
    },
    {
      id: "seat-2",
      number: 2,
      label: "Место 2",
      color: "#29b5c8",
      hint: "бирюзовая фигура — правый борт",
    },
    {
      id: "seat-3",
      number: 3,
      label: "Место 3",
      color: "#7d7250",
      hint: "оливковая фигура — правая корма",
    },
    {
      id: "seat-4",
      number: 4,
      label: "Место 4",
      color: "#e0512a",
      hint: "оранжевая фигура — левая корма",
    },
    {
      id: "seat-5",
      number: 5,
      label: "Место 5",
      color: "#7cb544",
      hint: "зелёная фигура — левый борт",
    },
  ],
};

export const capacity = event.seats.length;

// Публичная часть события — то, что отдаём браузеру.
export function publicEvent() {
  return {
    id: event.id,
    title: event.title,
    venue: event.venue,
    date: event.date,
    dateLabel: event.dateLabel,
    time: event.time,
    endTime: event.endTime,
    meetingPoint: event.meetingPoint,
    address: event.address,
    price: event.price,
    currency: event.currency,
    ageLimit: event.ageLimit,
    capacity,
  };
}
