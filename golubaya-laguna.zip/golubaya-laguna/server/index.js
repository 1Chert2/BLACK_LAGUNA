import express from "express";
import path from "node:path";
import { promises as fs } from "node:fs";
import { fileURLToPath } from "node:url";
import { publicEvent, event } from "./event.js";
import {
  initDb,
  listSeats,
  countFreeSeats,
  createBooking,
  findBooking,
  markUsed,
  cancelBooking,
} from "./db.js";
import { validateBooking } from "./validation.js";
import { DomainError, STATUS_BY_CODE } from "./errors.js";
import { toTicket } from "./views.js";
import { isValidTicketCode } from "./tickets.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const distDir = path.resolve(here, "..", "dist");
const PORT = Number(process.env.PORT) || 3001;

const app = express();

app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));

app.use((req, res, next) => {
  res.on("finish", () => {
    if (req.path.startsWith("/api")) {
      console.log(`${req.method} ${req.originalUrl} → ${res.statusCode}`);
    }
  });
  next();
});

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    event: event.id,
    seats: listSeats().length,
    freeSeats: countFreeSeats(),
  });
});

// Данные для первого экрана: событие + карта мест одним запросом.
app.get("/api/event", (req, res) => {
  res.json({ event: publicEvent(), seats: listSeats(), freeSeats: countFreeSeats() });
});

// Отдельный лёгкий метод, чтобы обновить занятость после конфликта или выдачи проходки.
app.get("/api/seats", (req, res) => {
  res.json({ seats: listSeats(), freeSeats: countFreeSeats() });
});

app.post("/api/bookings", async (req, res, next) => {
  try {
    const { errors, values } = validateBooking(req.body);

    if (Object.keys(errors).length > 0) {
      throw new DomainError("VALIDATION_ERROR", "Проверьте заполнение полей", errors);
    }

    const booking = await createBooking({ ...values, seatId: req.body?.seatId });

    res.status(201).json({ ticket: toTicket(booking) });
  } catch (error) {
    next(error);
  }
});

// Тикет самого гостя: контакты полностью, по нему можно восстановить билет на этом устройстве.
app.get("/api/tickets/:code", (req, res) => {
  if (!isValidTicketCode(req.params.code)) {
    return res
      .status(404)
      .json({ error: { code: "TICKET_NOT_FOUND", message: "Неверный формат кода тикета" } });
  }

  const booking = findBooking(req.params.code);

  if (!booking) {
    return res
      .status(404)
      .json({ error: { code: "TICKET_NOT_FOUND", message: "Тикет с таким кодом не найден" } });
  }

  res.json({ ticket: toTicket(booking) });
});

// Отмена брони самим гостем: место возвращается в свободные.
// В ответ кладём свежую карту мест, чтобы браузер обновил схему одним запросом.
app.delete("/api/tickets/:code", async (req, res, next) => {
  try {
    const booking = await cancelBooking(req.params.code);

    res.json({
      cancelled: booking.code,
      seatId: booking.seatId,
      seats: listSeats(),
      freeSeats: countFreeSeats(),
    });
  } catch (error) {
    next(error);
  }
});

// Страница контроля: ищем тикет, контакты маскируем.
app.get("/api/check/:code", (req, res) => {
  const booking = findBooking(req.params.code);

  if (!booking) {
    return res
      .status(404)
      .json({ error: { code: "TICKET_NOT_FOUND", message: "Тикет с таким кодом не найден" } });
  }

  res.json({ ticket: toTicket(booking, { contact: "masked" }) });
});

// Выдача проходки на месте встречи: тикет помечается использованным, второй раз выдать нельзя.
app.post("/api/check/:code", async (req, res, next) => {
  try {
    const booking = await markUsed(req.params.code);

    res.json({ ticket: toTicket(booking, { contact: "masked" }) });
  } catch (error) {
    next(error);
  }
});

app.use("/api", (req, res) => {
  res.status(404).json({
    error: { code: "NOT_FOUND", message: `Метода ${req.method} ${req.originalUrl} не существует` },
  });
});

app.use((error, req, res, next) => {
  if (error instanceof DomainError) {
    return res.status(STATUS_BY_CODE[error.code] ?? 400).json({
      error: { code: error.code, message: error.message, fields: error.fields },
    });
  }

  if (error?.type === "entity.parse.failed") {
    return res
      .status(400)
      .json({ error: { code: "BAD_JSON", message: "В теле запроса не JSON" } });
  }

  console.error(error);
  res.status(500).json({ error: { code: "INTERNAL", message: "Внутренняя ошибка сервера" } });
});

// Прод-режим: раздаём собранную статику из dist/. В dev её нет — фронтенд отдаёт Vite.
const hasBuild = await fs
  .access(path.join(distDir, "index.html"))
  .then(() => true)
  .catch(() => false);

if (hasBuild) {
  app.use(express.static(distDir));
  app.use((req, res, next) => {
    if (req.method !== "GET") {
      return next();
    }

    res.sendFile(path.join(distDir, "index.html"));
  });
} else {
  app.get("/", (req, res) => {
    res
      .type("text/plain; charset=utf-8")
      .send(
        "API «Голубая Лагуна» работает.\nСайт в dev-режиме: http://localhost:5173 (npm run dev).\nПрод-сборка: npm run build && npm start.\n"
      );
  });
}

const dbInfo = await initDb();

app.listen(PORT, () => {
  console.log(`«Голубая Лагуна»: API на http://localhost:${PORT}`);
  console.log(`Файл бронирований: ${dbInfo.file} (записей: ${dbInfo.bookings})`);

  if (!hasBuild) {
    console.log("Папки dist/ нет — фронтенд запускайте через npm run dev");
  }
});
