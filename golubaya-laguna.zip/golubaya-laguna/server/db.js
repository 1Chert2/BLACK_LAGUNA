import { promises as fs } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { event } from "./event.js";
import { DomainError } from "./errors.js";
import { generateTicketCode, toTicketCode } from "./tickets.js";

// База — обычный JSON-файл. Для четырёх мест и одного события этого достаточно:
// ничего ставить не нужно, а все брони видны в одном месте и переживают перезапуск.
// Путь можно переопределить через DB_FILE — так делает smoke-тест, чтобы не трогать
// реальные брони.
const here = path.dirname(fileURLToPath(import.meta.url));
const DB_FILE = process.env.DB_FILE
  ? path.resolve(process.env.DB_FILE)
  : path.join(here, "db", "bookings.json");
const TMP_FILE = `${DB_FILE}.tmp`;

let bookings = [];
let writeQueue = Promise.resolve();

export async function initDb() {
  await fs.mkdir(path.dirname(DB_FILE), { recursive: true });

  try {
    const raw = await fs.readFile(DB_FILE, "utf8");
    const parsed = JSON.parse(raw);
    bookings = Array.isArray(parsed.bookings) ? parsed.bookings : [];
  } catch (error) {
    if (error.code !== "ENOENT") {
      throw error;
    }

    bookings = [];
    await persist();
  }

  return { file: DB_FILE, bookings: bookings.length };
}

// Пишем последовательно и через временный файл: если процесс упадёт посреди записи,
// основной файл останется целым.
function persist() {
  const snapshot = JSON.stringify(
    {
      updatedAt: new Date().toISOString(),
      eventId: event.id,
      bookings,
    },
    null,
    2
  );

  const task = writeQueue.then(async () => {
    await fs.writeFile(TMP_FILE, snapshot, "utf8");
    await fs.rename(TMP_FILE, DB_FILE);
  });

  // Одна неудачная запись не должна ломать очередь для следующих.
  writeQueue = task.catch(() => {});

  return task;
}

// Карта мест: к описанию места из конфига события примешиваем статус из броней.
// Статусы места и статуса брони — разные словари: схеме мест достаточно
// free/booked/used, а у брони ещё есть awaiting_payment (ждёт оплаты на месте).
const SEAT_STATUS_BY_BOOKING = {
  awaiting_payment: "booked",
  used: "used",
};

export function listSeats() {
  return event.seats.map((seat) => {
    const booking = bookings.find((item) => item.seatId === seat.id);

    return {
      id: seat.id,
      number: seat.number,
      label: seat.label,
      color: seat.color,
      hint: seat.hint,
      price: event.price,
      currency: event.currency,
      status: booking ? SEAT_STATUS_BY_BOOKING[booking.status] ?? "booked" : "free",
    };
  });
}

export function countFreeSeats() {
  return listSeats().filter((seat) => seat.status === "free").length;
}

export async function createBooking({ seatId, name, phone, email }) {
  const seat = event.seats.find((item) => item.id === seatId);

  if (!seat) {
    throw new DomainError("UNKNOWN_SEAT", "Такого места нет на схеме", {
      seatId: "Выберите место со схемы",
    });
  }

  if (bookings.some((item) => item.seatId === seatId)) {
    throw new DomainError("SEAT_TAKEN", "Это место только что заняли. Выберите другое.");
  }

  // Между проверкой и push нет ни одного await, поэтому две одновременные заявки
  // на одно место разойтись не могут: Node выполняет этот участок целиком.
  const booking = {
    code: generateTicketCode((candidate) => bookings.some((item) => item.code === candidate)),
    name,
    phone,
    email,
    seatId: seat.id,
    seatNumber: seat.number,
    seatLabel: seat.label,
    price: event.price,
    currency: event.currency,
    status: "awaiting_payment",
    createdAt: new Date().toISOString(),
    usedAt: null,
  };

  bookings.push(booking);
  await persist();

  return booking;
}

export function findBooking(rawCode) {
  const code = toTicketCode(rawCode);

  return bookings.find((item) => item.code === code) ?? null;
}

export async function markUsed(rawCode) {
  const booking = findBooking(rawCode);

  if (!booking) {
    throw new DomainError("TICKET_NOT_FOUND", "Тикет с таким кодом не найден");
  }

  if (booking.status === "used") {
    throw new DomainError("ALREADY_USED", "Проходка по этому тикету уже выдана");
  }

  booking.status = "used";
  booking.usedAt = new Date().toISOString();
  await persist();

  return booking;
}

// Отмена брони: место возвращается в свободные и его может занять другой гость.
// Бронь с выданной проходкой отменить нельзя — человек уже прошёл на встречу.
export async function cancelBooking(rawCode) {
  const booking = findBooking(rawCode);

  if (!booking) {
    throw new DomainError("TICKET_NOT_FOUND", "Тикет с таким кодом не найден");
  }

  if (booking.status === "used") {
    throw new DomainError(
      "ALREADY_USED",
      "Проходка по этому тикету уже выдана — отменить бронь нельзя"
    );
  }

  bookings = bookings.filter((item) => item.code !== booking.code);
  await persist();

  return booking;
}
