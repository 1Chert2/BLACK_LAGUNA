import { randomInt } from "node:crypto";

// Без I, O, 0 и 1 — код проще прочитать и продиктовать на входе.
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const CODE_LENGTH = 6;
export const TICKET_PREFIX = "GL";

function randomBody() {
  let body = "";

  for (let index = 0; index < CODE_LENGTH; index += 1) {
    body += ALPHABET[randomInt(ALPHABET.length)];
  }

  return body;
}

// Код подбираем до тех пор, пока не найдём свободный: тикет обязан быть уникальным,
// иначе на входе по одному коду найдутся два человека.
export function generateTicketCode(isTaken) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const code = `${TICKET_PREFIX}-${randomBody()}`;

    if (!isTaken(code)) {
      return code;
    }
  }

  throw new Error("Не удалось подобрать уникальный код тикета");
}

// Приводим ввод к виду GL-XXXXXX: на контроле код могут вбить строчными, с пробелом
// или вовсе без префикса.
export function toTicketCode(rawValue) {
  const cleaned = String(rawValue ?? "")
    .trim()
    .toUpperCase()
    .replace(/[\s]/g, "");

  if (!cleaned) {
    return "";
  }

  return cleaned.startsWith(`${TICKET_PREFIX}-`) ? cleaned : `${TICKET_PREFIX}-${cleaned}`;
}

export function isValidTicketCode(rawValue) {
  return new RegExp(`^${TICKET_PREFIX}-[A-Z0-9]{${CODE_LENGTH}}$`).test(toTicketCode(rawValue));
}
