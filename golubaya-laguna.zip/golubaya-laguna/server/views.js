import { event } from "./event.js";

const STATUS_LABELS = {
  awaiting_payment: "Ожидает оплаты на месте",
  used: "Проходка выдана",
};

// Телефон и email гостя — персональные данные. Организатору на контроле достаточно
// имени и места, поэтому для страницы контроля контакты маскируем.
export function maskPhone(phone) {
  const value = String(phone);
  const digitsTotal = value.replace(/\D/g, "").length;
  let seen = 0;

  // Закрываем все цифры, кроме двух последних.
  return value.replace(/\d/g, (digit) => {
    seen += 1;
    return seen <= digitsTotal - 2 ? "•" : digit;
  });
}

export function maskEmail(email) {
  const [name, domain] = String(email).split("@");

  if (!domain) {
    return email;
  }

  return `${name.slice(0, 1)}${"•".repeat(Math.max(name.length - 1, 1))}@${domain}`;
}

// Представление брони для ответа API. contact: "full" — для самого гостя,
// "masked" — для страницы контроля.
export function toTicket(booking, { contact = "full" } = {}) {
  const seat = event.seats.find((item) => item.id === booking.seatId) ?? null;

  return {
    code: booking.code,
    name: booking.name,
    phone: contact === "masked" ? maskPhone(booking.phone) : booking.phone,
    email: contact === "masked" ? maskEmail(booking.email) : booking.email,
    seat: seat
      ? { id: seat.id, number: seat.number, label: seat.label, color: seat.color, hint: seat.hint }
      : { id: booking.seatId, number: booking.seatNumber, label: booking.seatLabel },
    price: booking.price,
    currency: booking.currency,
    status: booking.status,
    statusLabel: STATUS_LABELS[booking.status] ?? booking.status,
    createdAt: booking.createdAt,
    usedAt: booking.usedAt ?? null,
    event: {
      title: event.title,
      venue: event.venue,
      dateLabel: event.dateLabel,
      time: event.time,
      meetingPoint: event.meetingPoint,
      address: event.address,
    },
  };
}
