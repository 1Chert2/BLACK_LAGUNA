// Правила заполнения формы брони. Сообщения сразу на русском —
// они уходят в ответе 422 и показываются под полями формы.

const NAME_PATTERN = /^[\p{L}][\p{L}\s'’-]{1,59}$/u;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_PATTERN = /^\+?[\d\s()-]{10,24}$/;

function digitsCount(value) {
  return String(value).replace(/\D/g, "").length;
}

export function validateBooking(body) {
  const errors = {};

  const name = String(body?.name ?? "").trim().replace(/\s+/g, " ");
  const phone = String(body?.phone ?? "").trim();
  const email = String(body?.email ?? "").trim().toLowerCase();

  if (!name) {
    errors.name = "Укажите имя — по нему вас найдут на месте встречи";
  } else if (!NAME_PATTERN.test(name)) {
    errors.name = "Имя: от 2 до 60 букв, без цифр и специальных символов";
  }

  if (!phone) {
    errors.phone = "Укажите телефон для связи";
  } else if (!PHONE_PATTERN.test(phone) || digitsCount(phone) < 10 || digitsCount(phone) > 15) {
    errors.phone = "Телефон в формате +7 900 000-00-00";
  }

  if (!email) {
    errors.email = "Укажите email — на него можно продублировать тикет";
  } else if (email.length > 120 || !EMAIL_PATTERN.test(email)) {
    errors.email = "Проверьте адрес почты, например name@mail.ru";
  }

  return { errors, values: { name, phone, email } };
}
