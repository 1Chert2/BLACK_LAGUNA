// Ошибка с понятным кодом: по коду Express подбирает HTTP-статус,
// а фронтенд отличает «место заняли» (409) от «поля заполнены неверно» (422).
export class DomainError extends Error {
  constructor(code, message, fields = null) {
    super(message);
    this.name = "DomainError";
    this.code = code;
    this.fields = fields;
  }
}

export const STATUS_BY_CODE = {
  VALIDATION_ERROR: 422,
  UNKNOWN_SEAT: 422,
  SEAT_TAKEN: 409,
  TICKET_NOT_FOUND: 404,
  ALREADY_USED: 409,
};
