@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

rem PORT подхватит server/index.js: Number(process.env.PORT) || 3001.
rem Он же используется в проверке занятости порта и в адресе для браузера.
set "PORT=3001"
set "URL=http://localhost:%PORT%"
title Голубая Лагуна — локальный сервер

echo.
echo  =============================================
echo    «Голубая Лагуна» — локальный сервер
echo  =============================================
echo.

rem --- 1. Сервер уже поднят (батник запустили дважды)? Ничего не убиваем. -------
rem Спрашиваем наш же /api/health через curl (есть в Windows 10 1803+).
rem netstat+findstr здесь не годится: конвейер из двух findstr после chcp 65001
rem работает нестабильно, а состояние "LISTENING" в netstat зависит от локали.
rem -f: считаем сервером только ответ 2xx, а не любой процесс на этом порту.
curl -sf -o nul -m 2 "%URL%/api/health" >nul 2>&1
if not errorlevel 1 goto already_running

rem --- 2. Node.js: свежая установка не всегда видна в PATH открытых сессий. -----
where npm >nul 2>&1
if not errorlevel 1 goto node_ok
if exist "%ProgramFiles%\nodejs\npm.cmd" set "PATH=%ProgramFiles%\nodejs;%PATH%"
where npm >nul 2>&1
if not errorlevel 1 goto node_ok
echo Не найден npm. Установите Node.js LTS:
echo     winget install OpenJS.NodeJS.LTS
echo или скачайте с https://nodejs.org — затем перезапустите этот файл.
goto error
:node_ok

rem --- 3. Зависимости: node_modules/ в git не хранится. -------------------------
if exist "node_modules\" goto deps_ok
echo Ставлю зависимости: npm install ...
echo.
call npm install
if errorlevel 1 goto error
:deps_ok

rem --- 4. Пересборка: Express раздаёт dist/, поэтому он должен быть свежим. -----
echo Собираю фронтенд: npm run build ...
echo.
call npm run build
if errorlevel 1 goto error

rem --- 5. Браузер — отдельным процессом и с задержкой, когда порт уже слушается. -
rem ping вместо timeout: не зависит от перенаправления stdin.
rem URL без кавычек, иначе start примет его за заголовок окна.
start "" /min cmd /c "ping -n 6 127.0.0.1 >nul & start %URL%"

rem --- 6. Сервер в этом же окне и в foreground: Ctrl+C гасит всё. ---------------
echo.
echo Сервер запускается: %URL%
echo Остановить — Ctrl+C в этом окне либо закрыть его.
echo.
call npm start
if errorlevel 1 goto error

endlocal
exit /b 0

:already_running
echo Сервер уже работает на %URL% — второй процесс не запускаю.
echo Открываю браузер.
start "" %URL%
endlocal
exit /b 0

:error
echo.
echo Ошибка: сервер не запущен. Сообщение об ошибке — выше.
endlocal
pause
exit /b 1
