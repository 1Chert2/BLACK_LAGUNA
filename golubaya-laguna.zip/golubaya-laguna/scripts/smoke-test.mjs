// Сквозной тест API: поднимает сервер на отдельном порту с временным файлом-базой
// (реальные брони не задевает) и проходит весь путь гостя и организатора.
//
// Запуск: npm run smoke

import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const PORT = Number(process.env.SMOKE_PORT) || 3999;
const BASE = `http://127.0.0.1:${PORT}`;

const GUEST = { name: "Иван Петров", phone: "+7 900 000-00-00", email: "ivan@mail.ru" };
const OTHER_GUEST = { name: "Пётр Иванов", phone: "+7 911 111-11-11", email: "petr@mail.ru" };

let passed = 0;
let failed = 0;
let serverExited = false;
let serverExitCode = null;

function check(label, condition, details = "") {
  if (condition) {
    passed += 1;
    console.log(`  ok    ${label}`);
  } else {
    failed += 1;
    console.log(`  FAIL  ${label}${details ? ` — ${details}` : ""}`);
  }
}

async function call(method, urlPath, body) {
  const response = await fetch(`${BASE}${urlPath}`, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });

  const text = await response.text();
  let data = null;

  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  return { status: response.status, data };
}

async function waitForServer(timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    if (serverExited) {
      throw new Error(`Сервер завершился раньше времени (код ${serverExitCode})`);
    }

    try {
      const response = await fetch(`${BASE}/api/health`);

      if (response.ok) {
        return;
      }
    } catch {
      // ещё поднимается
    }

    await new Promise((resolve) => setTimeout(resolve, 200));
  }

  throw new Error(`Сервер не ответил на /api/health за ${timeoutMs} мс`);
}

const tempDir = await mkdtemp(path.join(tmpdir(), "laguna-smoke-"));
const dbFile = path.join(tempDir, "bookings.json");

const server = spawn(process.execPath, [path.join(root, "server", "index.js")], {
  cwd: root,
  env: { ...process.env, PORT: String(PORT), DB_FILE: dbFile },
  stdio: ["ignore", "pipe", "pipe"],
});

const serverLog = [];
server.stdout.on("data", (chunk) => serverLog.push(chunk.toString()));
server.stderr.on("data", (chunk) => serverLog.push(chunk.toString()));
server.on("exit", (code) => {
  serverExited = true;
  serverExitCode = code;
});

try {
  await waitForServer();

  console.log("\n1. Событие и карта мест");
  const health = await call("GET", "/api/health");
  check("GET /api/health → 200", health.status === 200, `status ${health.status}`);

  const eventResponse = await call("GET", "/api/event");
  const eventData = eventResponse.data?.event;
  const seats = eventResponse.data?.seats ?? [];
  check("GET /api/event → 200", eventResponse.status === 200, `status ${eventResponse.status}`);
  check("цена за место 1500", eventData?.price === 1500, `price ${eventData?.price}`);
  check("возрастное ограничение 18+", eventData?.ageLimit === 18, `ageLimit ${eventData?.ageLimit}`);
  check("на схеме 5 мест", seats.length === 5, `получено ${seats.length}`);
  check("все места свободны", seats.every((seat) => seat.status === "free"));
  check(
    "у каждого места свой цвет фигуры эмблемы",
    new Set(seats.map((seat) => seat.color)).size === seats.length &&
      seats.every((seat) => /^#[0-9a-f]{6}$/i.test(seat.color ?? "")),
    seats.map((seat) => seat.color).join(",")
  );
  check(
    "у каждого места есть подсказка с цветом",
    seats.every((seat) => typeof seat.hint === "string" && seat.hint.length > 0)
  );

  console.log("\n2. Валидация формы брони");
  const invalid = await call("POST", "/api/bookings", {
    seatId: "seat-1",
    name: "И",
    phone: "123",
    email: "нет",
  });
  check("невалидные поля → 422", invalid.status === 422, `status ${invalid.status}`);
  check("есть замечание к имени", Boolean(invalid.data?.error?.fields?.name));
  check("есть замечание к телефону", Boolean(invalid.data?.error?.fields?.phone));
  check("есть замечание к email", Boolean(invalid.data?.error?.fields?.email));

  const unknownSeat = await call("POST", "/api/bookings", { ...GUEST, seatId: "seat-99" });
  check("несуществующее место → 422", unknownSeat.status === 422, `status ${unknownSeat.status}`);
  check(
    "код ошибки UNKNOWN_SEAT",
    unknownSeat.data?.error?.code === "UNKNOWN_SEAT",
    unknownSeat.data?.error?.code
  );

  console.log("\n3. Бронирование места и уникальный тикет");
  const booking = await call("POST", "/api/bookings", { ...GUEST, seatId: "seat-1" });
  const ticket = booking.data?.ticket;
  check("бронь создана → 201", booking.status === 201, `status ${booking.status}`);
  check(
    "код тикета формата GL-XXXXXX",
    /^GL-[A-Z0-9]{6}$/.test(ticket?.code ?? ""),
    `code ${ticket?.code}`
  );
  check(
    "в коде нет неоднозначных символов (I, O, 0, 1)",
    !/[IO01]/.test((ticket?.code ?? "").slice(3)),
    `code ${ticket?.code}`
  );
  check("статус «ожидает оплаты»", ticket?.status === "awaiting_payment", ticket?.status);
  check("место в тикете — seat-1", ticket?.seat?.id === "seat-1", ticket?.seat?.id);
  check("сумма в тикете 1500", ticket?.price === 1500, `price ${ticket?.price}`);

  const doubleBooking = await call("POST", "/api/bookings", { ...OTHER_GUEST, seatId: "seat-1" });
  check("второй гость на то же место → 409", doubleBooking.status === 409, `status ${doubleBooking.status}`);
  check(
    "код ошибки SEAT_TAKEN",
    doubleBooking.data?.error?.code === "SEAT_TAKEN",
    doubleBooking.data?.error?.code
  );

  const seatsAfterBooking = await call("GET", "/api/seats");
  check(
    "место 1 занято (статус booked)",
    seatsAfterBooking.data?.seats?.find((seat) => seat.id === "seat-1")?.status === "booked",
    `status ${seatsAfterBooking.data?.seats?.find((seat) => seat.id === "seat-1")?.status}`
  );
  check(
    "свободных мест осталось 4",
    seatsAfterBooking.data?.freeSeats === 4,
    `freeSeats ${seatsAfterBooking.data?.freeSeats}`
  );

  console.log("\n4. Тикет гостя и страница контроля");
  const ownTicket = await call("GET", `/api/tickets/${ticket.code}`);
  check("свой тикет по коду → 200", ownTicket.status === 200, `status ${ownTicket.status}`);
  check(
    "контакты гостя видны полностью",
    ownTicket.data?.ticket?.phone === GUEST.phone,
    ownTicket.data?.ticket?.phone
  );

  const controlTicket = await call("GET", `/api/check/${ticket.code}`);
  check("поиск тикета на контроле → 200", controlTicket.status === 200);
  check(
    "телефон на контроле замаскирован",
    String(controlTicket.data?.ticket?.phone).includes("•"),
    controlTicket.data?.ticket?.phone
  );
  check(
    "email на контроле замаскирован",
    String(controlTicket.data?.ticket?.email).includes("•"),
    controlTicket.data?.ticket?.email
  );

  const lowercaseCode = await call("GET", `/api/check/${ticket.code.toLowerCase()}`);
  check("код нечувствителен к регистру", lowercaseCode.status === 200, `status ${lowercaseCode.status}`);

  const missingTicket = await call("GET", "/api/check/GL-ZZZZZZ");
  check("несуществующий код → 404", missingTicket.status === 404, `status ${missingTicket.status}`);

  console.log("\n5. Выдача проходки на месте встречи");
  const issue = await call("POST", `/api/check/${ticket.code}`);
  check("проходка выдана → 200", issue.status === 200, `status ${issue.status}`);
  check("статус сменился на used", issue.data?.ticket?.status === "used", issue.data?.ticket?.status);
  check("записано время выдачи", Boolean(issue.data?.ticket?.usedAt));

  const reissue = await call("POST", `/api/check/${ticket.code}`);
  check("повторная выдача → 409", reissue.status === 409, `status ${reissue.status}`);
  check(
    "код ошибки ALREADY_USED",
    reissue.data?.error?.code === "ALREADY_USED",
    reissue.data?.error?.code
  );

  const seatsAfterIssue = await call("GET", "/api/seats");
  check(
    "место 1 помечено использованным",
    seatsAfterIssue.data?.seats?.find((seat) => seat.id === "seat-1")?.status === "used"
  );
  check(
    "статусы мест понимают free/booked/used (их рисует схема)",
    seatsAfterIssue.data?.seats?.every((seat) => ["free", "booked", "used"].includes(seat.status)),
    JSON.stringify(seatsAfterIssue.data?.seats?.map((seat) => seat.status))
  );

  console.log("\n6. Отмена брони освобождает место");
  const cancellable = await call("POST", "/api/bookings", { ...OTHER_GUEST, seatId: "seat-2" });
  const cancelCode = cancellable.data?.ticket?.code;
  check("бронь для отмены создана → 201", cancellable.status === 201, `status ${cancellable.status}`);

  const cancelUsed = await call("DELETE", `/api/tickets/${ticket.code}`);
  check(
    "отмена после выдачи проходки → 409",
    cancelUsed.status === 409,
    `status ${cancelUsed.status}`
  );
  check("код ошибки ALREADY_USED", cancelUsed.data?.error?.code === "ALREADY_USED");

  const cancel = await call("DELETE", `/api/tickets/${cancelCode}`);
  check("отмена брони → 200", cancel.status === 200, `status ${cancel.status}`);
  check(
    "место 2 снова свободно",
    cancel.data?.seats?.find((seat) => seat.id === "seat-2")?.status === "free",
    `status ${cancel.data?.seats?.find((seat) => seat.id === "seat-2")?.status}`
  );
  check(
    "свободных мест снова 4",
    cancel.data?.freeSeats === 4,
    `freeSeats ${cancel.data?.freeSeats}`
  );

  const cancelAgain = await call("DELETE", `/api/tickets/${cancelCode}`);
  check("повторная отмена → 404", cancelAgain.status === 404, `status ${cancelAgain.status}`);

  const cancelledTicket = await call("GET", `/api/tickets/${cancelCode}`);
  check(
    "отменённый тикет больше не находится → 404",
    cancelledTicket.status === 404,
    `status ${cancelledTicket.status}`
  );

  console.log("\n7. Полная посадка и прочее");
  for (const seatId of ["seat-2", "seat-3", "seat-4", "seat-5"]) {
    await call("POST", "/api/bookings", {
      seatId,
      name: "Гость Тестов",
      phone: "+7 900 111-22-33",
      email: "guest@mail.ru",
    });
  }

  const soldOut = await call("GET", "/api/seats");
  check("свободных мест не осталось", soldOut.data?.freeSeats === 0, `freeSeats ${soldOut.data?.freeSeats}`);

  const overflow = await call("POST", "/api/bookings", { ...OTHER_GUEST, seatId: "seat-2" });
  check("бронь сверх пяти мест → 409", overflow.status === 409, `status ${overflow.status}`);

  const unknownMethod = await call("GET", "/api/unknown");
  check("неизвестный API-метод → 404", unknownMethod.status === 404, `status ${unknownMethod.status}`);

  const badJson = await fetch(`${BASE}/api/bookings`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: "{не json",
  });
  check("битый JSON в теле → 400", badJson.status === 400, `status ${badJson.status}`);
} catch (error) {
  failed += 1;
  console.error(`\nТест не удалось выполнить: ${error.message}`);

  if (serverLog.length > 0) {
    console.error("\n--- вывод сервера ---");
    console.error(serverLog.join(""));
  }
} finally {
  server.kill();
  await new Promise((resolve) => setTimeout(resolve, 300));
  await rm(tempDir, { recursive: true, force: true });
}

console.log(`\nИтог: ${passed} проверок пройдено, ${failed} провалено.`);
process.exit(failed > 0 ? 1 : 0);
