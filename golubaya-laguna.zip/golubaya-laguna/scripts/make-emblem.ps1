# Готовит эмблему для сайта из исходной картинки public/ship-wheel.jpg:
# вырезает квадрат с переплетёнными фигурами (без подписи «Голландский штурвал»)
# и делает белый фон прозрачным, чтобы эмблема ложилась и на тёмную шапку, и на белые карточки.
#
# Запуск: powershell -NoProfile -ExecutionPolicy Bypass -File scripts/make-emblem.ps1

Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $PSScriptRoot
$srcPath = Join-Path $root 'public\ship-wheel.jpg'
$dstPath = Join-Path $root 'public\ship-wheel-emblem.png'

# Квадрат подобран по геометрии исходника 640x700: фигуры занимают x 110..530, y 40..465,
# подпись начинается ниже y 480 — в кадр не попадает.
$crop = New-Object System.Drawing.Rectangle(90, 20, 460, 460)

$src = [System.Drawing.Image]::FromFile($srcPath)
$bmp = New-Object System.Drawing.Bitmap($crop.Width, $crop.Height)
$graphics = [System.Drawing.Graphics]::FromImage($bmp)
$graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$dest = New-Object System.Drawing.Rectangle(0, 0, $crop.Width, $crop.Height)
$graphics.DrawImage($src, $dest, $crop, [System.Drawing.GraphicsUnit]::Pixel)
$graphics.Dispose()

# Белый фон исходника (255,255,255) и его JPEG-шум делаем прозрачным.
$transparent = 0
for ($y = 0; $y -lt $bmp.Height; $y++) {
  for ($x = 0; $x -lt $bmp.Width; $x++) {
    $pixel = $bmp.GetPixel($x, $y)
    if ($pixel.R -ge 245 -and $pixel.G -ge 245 -and $pixel.B -ge 245) {
      $bmp.SetPixel($x, $y, [System.Drawing.Color]::FromArgb(0, 255, 255, 255))
      $transparent++
    }
  }
}

$bmp.Save($dstPath, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Output ("saved {0} ({1}x{2}, transparent px: {3})" -f $dstPath, $bmp.Width, $bmp.Height, $transparent)

$bmp.Dispose()
$src.Dispose()
