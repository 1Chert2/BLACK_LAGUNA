// Тест рендера: рисует компоненты в строку через react-dom/server и проверяет,
// что на экранах есть нужный текст и состояния. Работает без браузера, поэтому
// ловит опечатки в компонентах и поломанные props до открытия страницы.
//
// Запуск: npm run test:render
// (npm-скрипт сначала собирает этот файл в node_modules/.cache через esbuild —
// Node не умеет исполнять .jsx напрямую.)

import ReactDOMServer from "react-dom/server";
import React from "react";

import App from "../src/App.jsx";
import AgeGate from "../src/components/AgeGate.jsx";
import Alert from "../src/components/Alert.jsx";
import BlockedScreen from "../src/components/BlockedScreen.jsx";
import BookingForm from "../src/components/BookingForm.jsx";
import CheckIn from "../src/components/CheckIn.jsx";
import EventCard from "../src/components/EventCard.jsx";
import Footer from "../src/components/Footer.jsx";
import Header from "../src/components/Header.jsx";
import Legend from "../src/components/Legend.jsx";
import Seat from "../src/components/Seat.jsx";
import ShipWheel from "../src/components/ShipWheel.jsx";
import TicketCard from "../src/components/TicketCard.jsx";
import WheelMap from "../src/components/WheelMap.jsx";

const { renderToString } = ReactDOMServer;

// App читает hash и storage в конструкторе — подставляем заглушки.
globalThis.window = {
  location: { hash: "" },
  addEventListener() {},
  removeEventListener() {},
};
globalThis.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };

let sessionStore = {};
globalThis.sessionStorage = {
  getItem: (key) => sessionStore[key] ?? null,
  setItem: (key, value) => {
    sessionStore[key] = value;
  },
  removeItem: (key) => {
    delete sessionStore[key];
  },
};

const eventData = {
  id: "shturval-2026-11-21",
  title: "Голландский штурвал",
  venue: "Голубая Лагуна",
  date: "2026-11-21",
  dateLabel: "Суббота, 21 ноября 2026",
  time: "19:00",
  endTime: "23:00",
  meetingPoint: "Причал «Голубая Лагуна», сбор у трапа за 30 минут до отправления",
  address: "Лазурная набережная, 4",
  price: 1500,
  currency: "RUB",
  ageLimit: 18,
  capacity: 4,
};

const seats = [
  { id: "seat-1", number: 1, label: "Место 1", color: "#e9d26b", hint: "жёлтая фигура — лицом к капитану", price: 1500, currency: "RUB", status: "free" },
  { id: "seat-2", number: 2, label: "Место 2", color: "#29b5c8", hint: "бирюзовая фигура — правый борт", price: 1500, currency: "RUB", status: "booked" },
  { id: "seat-3", number: 3, label: "Место 3", color: "#7d7250", hint: "оливковая фигура — правая корма", price: 1500, currency: "RUB", status: "used" },
  { id: "seat-4", number: 4, label: "Место 4", color: "#e0512a", hint: "оранжевая фигура — левая корма", price: 1500, currency: "RUB", status: "free" },
  { id: "seat-5", number: 5, label: "Место 5", color: "#7cb544", hint: "зелёная фигура — левый борт", price: 1500, currency: "RUB", status: "free" },
];

const ticket = {
  code: "GL-ABC234",
  name: "Иван Петров",
  phone: "+7 900 000-00-00",
  email: "ivan@mail.ru",
  seat: { id: "seat-1", number: 1, label: "Место 1", color: "#e9d26b", hint: "жёлтая фигура — лицом к капитану" },
  price: 1500,
  currency: "RUB",
  status: "awaiting_payment",
  statusLabel: "Ожидает оплаты на месте",
  createdAt: "2026-11-05T10:00:00.000Z",
  usedAt: null,
  event: {
    title: eventData.title,
    venue: eventData.venue,
    dateLabel: eventData.dateLabel,
    time: eventData.time,
    meetingPoint: eventData.meetingPoint,
    address: eventData.address,
  },
};

const noop = () => {};
let failures = 0;

function expect(label, condition) {
  if (condition) {
    console.log(`  ok    ${label}`);
  } else {
    failures += 1;
    console.log(`  FAIL  ${label}`);
  }
}

function render(label, element) {
  try {
    const html = renderToString(element);
    expect(`${label}: отрендерился (${html.length} символов)`, html.length > 0);
    // React разделяет соседние текстовые узлы комментариями <!-- --> —
    // убираем их, чтобы поиск по тексту не спотыкался о вставки {выражений}.
    return html.replace(/<!--[^>]*-->/g, "");
  } catch (error) {
    failures += 1;
    console.log(`  FAIL  ${label}: ${error.message}`);
    return "";
  }
}

console.log("\nВозрастной шлюз и блокировка");
sessionStore = {};
const gateHtml = render("App (возрастной шлюз)", React.createElement(App));
expect("спрашивает про 18 лет", gateHtml.includes("Вам уже исполнилось 18 лет?"));
expect("есть кнопки «Да» и «Нет»", gateHtml.includes("Да, мне есть 18") && gateHtml.includes("Нет"));
expect("контент сайта не показан", !gateHtml.includes("Выберите место у штурвала"));
expect("фон сайта — класс lagoon-bg", gateHtml.includes("lagoon-bg"));

sessionStore = { "golubaya-laguna:age-declined": "1" };
const blockedHtml = render("App (после ответа «Нет»)", React.createElement(App));
expect("страница заблокирована", blockedHtml.includes("Доступ закрыт"));
expect("нет кнопок возврата", !blockedHtml.includes("<button"));
expect("экран блокировки на том же фоне", blockedHtml.includes("lagoon-bg"));
sessionStore = {};

console.log("\nЭкраны и компоненты");
render("AgeGate", React.createElement(AgeGate, { onAccept: noop, onDecline: noop }));
render("BlockedScreen", React.createElement(BlockedScreen, {}));
render("ShipWheel", React.createElement(ShipWheel, {}));
render("Legend", React.createElement(Legend, {}));
render("Footer", React.createElement(Footer, {}));
render("Alert", React.createElement(Alert, { tone: "error", title: "Ошибка" }, "Текст"));

const headerHtml = render(
  "Header",
  React.createElement(Header, {
    route: "booking",
    savedCode: "GL-ABC234",
    showSavedTicket: true,
    onShowTicket: noop,
  })
);
expect("в шапке есть «Голубая Лагуна»", headerHtml.includes("Голубая Лагуна"));
expect("есть ссылка на контроль", headerHtml.includes("#/check"));
expect("есть кнопка «Мой тикет»", headerHtml.includes("Мой тикет GL-ABC234"));

const eventHtml = render(
  "EventCard",
  React.createElement(EventCard, { event: eventData, freeSeats: 3, totalSeats: 5 })
);
expect("показана цена 1500 ₽", /1[\s\u00a0\u202f]?500/.test(eventHtml) && eventHtml.includes("₽"));
expect("показан счётчик свободных мест", eventHtml.includes("Свободно 3 из 5"));

const mapHtml = render(
  "WheelMap",
  React.createElement(WheelMap, { seats, selectedSeatId: "seat-1", onSelect: noop })
);
expect("пять кнопок-мест", (mapHtml.match(/aria-pressed/g) ?? []).length === 5);
expect("свободное место получило цвет фигуры", mapHtml.includes("#e9d26b"));
expect("эмблема в центре схемы", mapHtml.includes("ship-wheel-emblem.png"));
expect("свободное место подписано", mapHtml.includes("свободно"));
expect("занятое место подписано", mapHtml.includes("занято"));
expect("выданная проходка подписана", mapHtml.includes("выдано"));
expect("выбранное место отмечено", mapHtml.includes("ваше место"));
expect("занятое место отключено", mapHtml.includes("disabled"));
render("Seat", React.createElement(Seat, { seat: seats[0], onSelect: noop }));

const formHtml = render(
  "BookingForm",
  React.createElement(BookingForm, {
    seat: seats[0],
    price: 1500,
    currency: "RUB",
    onSubmit: noop,
    onCancel: noop,
  })
);
expect("форма предлагает забронировать место 1", formHtml.includes("Забронировать место 1"));
expect(
  "есть поля имени, телефона и email",
  formHtml.includes("booking-name") && formHtml.includes("booking-phone") && formHtml.includes("booking-email")
);

const conflictHtml = render(
  "BookingForm (конфликт 409)",
  React.createElement(BookingForm, {
    seat: { ...seats[0], status: "booked" },
    price: 1500,
    conflict: true,
    onSubmit: noop,
    onCancel: noop,
  })
);
expect("сообщает, что место заняли", conflictHtml.includes("Это место уже заняли"));
expect("кнопка брони отключена", conflictHtml.includes("disabled"));

const ticketHtml = render(
  "TicketCard",
  React.createElement(TicketCard, { ticket, onBack: noop, onCancel: noop })
);
expect("показан код тикета", ticketHtml.includes("GL-ABC234"));
expect("показан номер места", ticketHtml.includes("№ 1"));
expect("показан статус оплаты", ticketHtml.includes("Ожидает оплаты на месте"));
expect("есть кнопка печати", ticketHtml.includes("Распечатать тикет"));
expect("есть кнопка отмены брони", ticketHtml.includes("Отменить бронь и удалить тикет с устройства"));

const usedTicketHtml = render(
  "TicketCard (проходка выдана)",
  React.createElement(TicketCard, {
    ticket: { ...ticket, status: "used", statusLabel: "Проходка выдана" },
    onBack: noop,
    onCancel: noop,
  })
);
expect(
  "после выдачи проходки отмена недоступна",
  usedTicketHtml.includes("Бронь не отменить: проходка выдана")
);

const checkInHtml = render("CheckIn", React.createElement(CheckIn, {}));
expect("страница контроля", checkInHtml.includes("Контроль тикетов"));
expect("есть поле ввода кода", checkInHtml.includes("check-code"));
expect("есть кнопка поиска тикета", checkInHtml.includes("Найти тикет"));

console.log(`\nИтог: ${failures === 0 ? "все проверки рендера пройдены" : `${failures} провалов`}`);
process.exit(failures === 0 ? 0 : 1);
